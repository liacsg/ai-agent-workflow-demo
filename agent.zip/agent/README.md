# Study Buddy Agent

## 安装
```bash
pip install -r requirements.txt