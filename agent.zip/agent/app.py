import streamlit as st
from ingest import ingest_pdf
from distill import generate_flashcards
from vector_store import store_chunks
from tutor import ask_question

st.set_page_config(page_title="Study Buddy", layout="wide")
st.title("📚 Study Buddy Agent")

uploaded_file = st.file_uploader("Upload Lecture PDF", type="pdf")

if uploaded_file:
    chunks = ingest_pdf(uploaded_file)
    store_chunks(chunks)
    st.success("✅ PDF processed and stored!")

    if st.button("Generate Flashcards"):
        flashcards = generate_flashcards(chunks)
        for i, fc in enumerate(flashcards):
            st.markdown(f"**Q{i+1}: {fc['q']}**")
            st.write(fc['a'])

st.divider()

question = st.text_input("💬 Ask a question about your notes")
if question:
    answer = ask_question(question)
    st.write(answer)